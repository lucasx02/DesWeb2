import express from "express";
import { engine } from "express-handlebars";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { Diretor, Artista, Filme, FichaTecnica } from "./models.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.engine(
  "handlebars",
  engine({
    defaultLayout: "main",
    layoutsDir: path.join(__dirname, "views/layouts"),
    helpers: {
      eq: (a, b) => a == b,
      formatDate: (dateStr) => {
        if (!dateStr) return "—";
        const [y, m, d] = dateStr.split("-");
        return `${d}/${m}/${y}`;
      },
    },
  })
);
app.set("view engine", "handlebars");
app.set("views", path.join(__dirname, "views"));

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

// ===================== DASHBOARD =====================
app.get("/", async (req, res) => {
  try {
    const [totalDiretores, totalArtistas, totalFilmes, totalFichas] = await Promise.all([
      Diretor.count(),
      Artista.count(),
      Filme.count(),
      FichaTecnica.count(),
    ]);
    res.render("dashboard", {
      title: "Dashboard",
      totalDiretores,
      totalArtistas,
      totalFilmes,
      totalFichas,
    });
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

// ===================== DIRETORES =====================
app.get("/diretores", async (req, res) => {
  try {
    const diretores = await Diretor.findAll({
      order: [["nome", "ASC"]],
      include: [{ as: "filmes" }],
    });
    res.render("diretores/listar", { title: "Diretores", diretores });
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.get("/diretores/novo", (req, res) => {
  res.render("diretores/form", { title: "Cadastrar Diretor", diretor: {} });
});

app.post("/diretores", async (req, res) => {
  try {
    const { nome, nacionalidade, dataNascimento } = req.body;
    await Diretor.create({ nome, nacionalidade, dataNascimento: dataNascimento || null });
    res.redirect("/diretores");
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.get("/diretores/:id", async (req, res) => {
  try {
    const diretor = await Diretor.findByPk(req.params.id, {
      include: [{ as: "filmes" }],
    });
    if (!diretor) return res.status(404).render("error", { message: "Diretor não encontrado" });
    res.render("diretores/detalhar", { title: "Detalhes do Diretor", diretor });
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.get("/diretores/:id/editar", async (req, res) => {
  try {
    const diretor = await Diretor.findByPk(req.params.id);
    if (!diretor) return res.status(404).render("error", { message: "Diretor não encontrado" });
    res.render("diretores/form", { title: "Editar Diretor", diretor, editando: true });
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.post("/diretores/:id", async (req, res) => {
  try {
    const { nome, nacionalidade, dataNascimento } = req.body;
    await Diretor.update(req.params.id, { nome, nacionalidade, dataNascimento: dataNascimento || null });
    res.redirect(`/diretores/${req.params.id}`);
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.post("/diretores/:id/excluir", async (req, res) => {
  try {
    // Remove filmes do diretor e fichas técnicas desses filmes
    const filmes = await Filme.findAll();
    const filmesDoDiretor = filmes.filter((f) => f.diretorId === Number(req.params.id));
    for (const filme of filmesDoDiretor) {
      const fichas = await FichaTecnica.findAll();
      for (const ficha of fichas.filter((ft) => ft.filmeId === filme.id)) {
        await FichaTecnica.destroy(ficha.id);
      }
      await Filme.destroy(filme.id);
    }
    await Diretor.destroy(req.params.id);
    res.redirect("/diretores");
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

// ===================== ARTISTAS =====================
app.get("/artistas", async (req, res) => {
  try {
    const artistas = await Artista.findAll({
      order: [["nome", "ASC"]],
      include: [{ as: "participacoes" }],
    });
    res.render("artistas/listar", { title: "Artistas", artistas });
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.get("/artistas/novo", (req, res) => {
  res.render("artistas/form", { title: "Cadastrar Artista", artista: {} });
});

app.post("/artistas", async (req, res) => {
  try {
    const { nome, nacionalidade, dataNascimento } = req.body;
    await Artista.create({ nome, nacionalidade, dataNascimento: dataNascimento || null });
    res.redirect("/artistas");
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.get("/artistas/:id", async (req, res) => {
  try {
    const artista = await Artista.findByPk(req.params.id, {
      include: [{ as: "participacoes" }],
    });
    if (!artista) return res.status(404).render("error", { message: "Artista não encontrado" });
    res.render("artistas/detalhar", { title: "Detalhes do Artista", artista });
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.get("/artistas/:id/editar", async (req, res) => {
  try {
    const artista = await Artista.findByPk(req.params.id);
    if (!artista) return res.status(404).render("error", { message: "Artista não encontrado" });
    res.render("artistas/form", { title: "Editar Artista", artista, editando: true });
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.post("/artistas/:id", async (req, res) => {
  try {
    const { nome, nacionalidade, dataNascimento } = req.body;
    await Artista.update(req.params.id, { nome, nacionalidade, dataNascimento: dataNascimento || null });
    res.redirect(`/artistas/${req.params.id}`);
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.post("/artistas/:id/excluir", async (req, res) => {
  try {
    const fichas = await FichaTecnica.findAll();
    for (const ficha of fichas.filter((ft) => ft.artistaId === Number(req.params.id))) {
      await FichaTecnica.destroy(ficha.id);
    }
    await Artista.destroy(req.params.id);
    res.redirect("/artistas");
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

// ===================== FILMES =====================
app.get("/filmes", async (req, res) => {
  try {
    const filmes = await Filme.findAll({
      order: [["ano", "DESC"]],
      include: [{ as: "diretor" }],
    });
    res.render("filmes/listar", { title: "Filmes", filmes });
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.get("/filmes/novo", async (req, res) => {
  try {
    const diretores = await Diretor.findAll({ order: [["nome", "ASC"]] });
    res.render("filmes/form", { title: "Cadastrar Filme", filme: {}, diretores });
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.post("/filmes", async (req, res) => {
  try {
    const { titulo, ano, genero, sinopse, diretorId } = req.body;
    await Filme.create({
      titulo,
      ano: Number(ano),
      genero,
      sinopse,
      diretorId: Number(diretorId),
    });
    res.redirect("/filmes");
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.get("/filmes/:id", async (req, res) => {
  try {
    const filme = await Filme.findByPk(req.params.id, {
      include: [{ as: "diretor" }, { as: "fichaTecnica" }],
    });
    if (!filme) return res.status(404).render("error", { message: "Filme não encontrado" });
    res.render("filmes/detalhar", { title: "Detalhes do Filme", filme });
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.get("/filmes/:id/editar", async (req, res) => {
  try {
    const [filme, diretores] = await Promise.all([
      Filme.findByPk(req.params.id),
      Diretor.findAll({ order: [["nome", "ASC"]] }),
    ]);
    if (!filme) return res.status(404).render("error", { message: "Filme não encontrado" });
    res.render("filmes/form", { title: "Editar Filme", filme, diretores, editando: true });
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.post("/filmes/:id", async (req, res) => {
  try {
    const { titulo, ano, genero, sinopse, diretorId } = req.body;
    await Filme.update(req.params.id, {
      titulo,
      ano: Number(ano),
      genero,
      sinopse,
      diretorId: Number(diretorId),
    });
    res.redirect(`/filmes/${req.params.id}`);
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.post("/filmes/:id/excluir", async (req, res) => {
  try {
    const fichas = await FichaTecnica.findAll();
    for (const ficha of fichas.filter((ft) => ft.filmeId === Number(req.params.id))) {
      await FichaTecnica.destroy(ficha.id);
    }
    await Filme.destroy(req.params.id);
    res.redirect("/filmes");
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

// ===================== FICHA TÉCNICA =====================
app.get("/fichas-tecnicas", async (req, res) => {
  try {
    const fichas = await FichaTecnica.findAll({
      order: [["id", "ASC"]],
      include: [{ as: "filme" }, { as: "artista" }],
    });
    res.render("fichas-tecnicas/listar", { title: "Fichas Técnicas", fichas });
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.get("/fichas-tecnicas/nova", async (req, res) => {
  try {
    const [filmes, artistas] = await Promise.all([
      Filme.findAll({ order: [["titulo", "ASC"]] }),
      Artista.findAll({ order: [["nome", "ASC"]] }),
    ]);
    res.render("fichas-tecnicas/form", {
      title: "Cadastrar Ficha Técnica",
      ficha: {},
      filmes,
      artistas,
    });
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.post("/fichas-tecnicas", async (req, res) => {
  try {
    const { filmeId, artistaId, papel } = req.body;
    await FichaTecnica.create({
      filmeId: Number(filmeId),
      artistaId: Number(artistaId),
      papel,
    });
    res.redirect("/fichas-tecnicas");
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.get("/fichas-tecnicas/:id", async (req, res) => {
  try {
    const ficha = await FichaTecnica.findByPk(req.params.id, {
      include: [{ as: "filme" }, { as: "artista" }],
    });
    if (!ficha) return res.status(404).render("error", { message: "Ficha técnica não encontrada" });
    res.render("fichas-tecnicas/detalhar", { title: "Detalhes da Ficha Técnica", ficha });
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.get("/fichas-tecnicas/:id/editar", async (req, res) => {
  try {
    const [ficha, filmes, artistas] = await Promise.all([
      FichaTecnica.findByPk(req.params.id),
      Filme.findAll({ order: [["titulo", "ASC"]] }),
      Artista.findAll({ order: [["nome", "ASC"]] }),
    ]);
    if (!ficha) return res.status(404).render("error", { message: "Ficha técnica não encontrada" });
    res.render("fichas-tecnicas/form", {
      title: "Editar Ficha Técnica",
      ficha,
      filmes,
      artistas,
      editando: true,
    });
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.post("/fichas-tecnicas/:id", async (req, res) => {
  try {
    const { filmeId, artistaId, papel } = req.body;
    await FichaTecnica.update(req.params.id, {
      filmeId: Number(filmeId),
      artistaId: Number(artistaId),
      papel,
    });
    res.redirect(`/fichas-tecnicas/${req.params.id}`);
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

app.post("/fichas-tecnicas/:id/excluir", async (req, res) => {
  try {
    await FichaTecnica.destroy(req.params.id);
    res.redirect("/fichas-tecnicas");
  } catch (err) {
    res.status(500).render("error", { message: err.message });
  }
});

// ===================== ERROR =====================
app.use((req, res) => {
  res.status(404).render("error", { message: "Página não encontrada" });
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
