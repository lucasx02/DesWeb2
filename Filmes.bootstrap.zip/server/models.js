import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dataPath = path.join(__dirname, "data.json");

const emptyData = () => ({
  diretores: [],
  artistas: [],
  filmes: [],
  fichasTecnicas: [],
});

function loadData() {
  try {
    return { ...emptyData(), ...JSON.parse(fs.readFileSync(dataPath, "utf8")) };
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
    const data = seedData();
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
    return data;
  }
}

function seedData() {
  return {
    diretores: [
      { id: 1, nome: "Christopher Nolan", nacionalidade: "Britânico", dataNascimento: "1970-07-30" },
      { id: 2, nome: "Greta Gerwig", nacionalidade: "Americana", dataNascimento: "1983-08-04" },
      { id: 3, nome: "Hayao Miyazaki", nacionalidade: "Japonês", dataNascimento: "1941-01-05" },
    ],
    artistas: [
      { id: 1, nome: "Cillian Murphy", nacionalidade: "Irlandês", dataNascimento: "1976-05-25" },
      { id: 2, nome: "Margot Robbie", nacionalidade: "Australiana", dataNascimento: "1990-07-02" },
      { id: 3, nome: "Ryan Gosling", nacionalidade: "Canadense", dataNascimento: "1980-11-12" },
      { id: 4, nome: "Timothée Chalamet", nacionalidade: "Americano", dataNascimento: "1995-12-27" },
      { id: 5, nome: "Saoirse Ronan", nacionalidade: "Irlandesa", dataNascimento: "1994-04-12" },
    ],
    filmes: [
      { id: 1, titulo: "Oppenheimer", ano: 2023, genero: "Drama / Biografia", sinopse: "A história de J. Robert Oppenheimer e o desenvolvimento da bomba atômica.", diretorId: 1 },
      { id: 2, titulo: "Barbie", ano: 2023, genero: "Comédia / Fantasia", sinopse: "Barbie deixa Barbieland e descobre o mundo real.", diretorId: 2 },
      { id: 3, titulo: "A Viagem de Chihiro", ano: 2001, genero: "Animação / Fantasia", sinopse: "Chihiro entra em um mundo mágico e precisa salvar seus pais.", diretorId: 3 },
      { id: 4, titulo: "Interestelar", ano: 2014, genero: "Ficção Científica / Drama", sinopse: "Uma equipe de exploradores viaja através de um buraco de minhoca no espaço.", diretorId: 1 },
    ],
    fichasTecnicas: [
      { id: 1, filmeId: 1, artistaId: 1, papel: "J. Robert Oppenheimer" },
      { id: 2, filmeId: 2, artistaId: 2, papel: "Barbie" },
      { id: 3, filmeId: 2, artistaId: 3, papel: "Ken" },
      { id: 4, filmeId: 4, artistaId: 1, papel: "Robert Fischer (participação)" },
      { id: 5, filmeId: 3, artistaId: 5, papel: "Chihiro (dublagem EN)" },
    ],
  };
}

let data = loadData();

function saveData() {
  const temporaryPath = `${dataPath}.tmp`;
  fs.writeFileSync(temporaryPath, JSON.stringify(data, null, 2));
  fs.renameSync(temporaryPath, dataPath);
}

function nextId(collection) {
  const rows = data[collection];
  return rows.length ? Math.max(...rows.map((r) => r.id)) + 1 : 1;
}

function sortRows(rows, order = []) {
  return [...rows].sort((a, b) => {
    for (const [field, direction = "ASC"] of order) {
      const left = a[field] ?? "";
      const right = b[field] ?? "";
      const comparison = String(left).localeCompare(String(right), "pt-BR", { numeric: true });
      if (comparison !== 0) return direction.toUpperCase() === "DESC" ? -comparison : comparison;
    }
    return 0;
  });
}

function addAssociations(modelName, item, include) {
  const result = { ...item };
  const includes = include ? (Array.isArray(include) ? include : [include]) : [];

  for (const entry of includes) {
    const alias = entry.as;
    if (modelName === "Filme" && alias === "diretor") {
      result.diretor = data.diretores.find((row) => row.id === item.diretorId) || null;
    } else if (modelName === "Filme" && alias === "fichaTecnica") {
      result.fichaTecnica = data.fichasTecnicas
        .filter((row) => row.filmeId === item.id)
        .map((ft) => {
          const artista = data.artistas.find((a) => a.id === ft.artistaId) || null;
          return { ...ft, artista };
        });
    } else if (modelName === "FichaTecnica" && alias === "filme") {
      result.filme = data.filmes.find((row) => row.id === item.filmeId) || null;
    } else if (modelName === "FichaTecnica" && alias === "artista") {
      result.artista = data.artistas.find((row) => row.id === item.artistaId) || null;
    } else if (modelName === "Diretor" && alias === "filmes") {
      result.filmes = data.filmes.filter((row) => row.diretorId === item.id);
    } else if (modelName === "Artista" && alias === "participacoes") {
      result.participacoes = data.fichasTecnicas
        .filter((row) => row.artistaId === item.id)
        .map((ft) => {
          const filme = data.filmes.find((f) => f.id === ft.filmeId) || null;
          return { ...ft, filme };
        });
    }

    if (entry.include) {
      const nested = result[alias];
      if (nested && !Array.isArray(nested)) {
        result[alias] = addAssociations(entry.model?.modelName || alias, nested, entry.include);
      }
    }
  }
  return result;
}

class LocalModel {
  static get rows() {
    return data[this.collection];
  }

  static async count() {
    return this.rows.length;
  }

  static async findAll({ order, include } = {}) {
    let rows = this.rows;
    if (order) rows = sortRows(rows, order);
    if (include) {
      return rows.map((item) => addAssociations(this.modelName, item, include));
    }
    return rows.map((item) => ({ ...item }));
  }

  static async findByPk(id, { include } = {}) {
    const item = this.rows.find((row) => row.id === Number(id));
    if (!item) return null;
    return include ? addAssociations(this.modelName, item, include) : { ...item };
  }

  static async create(values) {
    const id = nextId(this.collection);
    const item = { id, ...values };
    this.rows.push(item);
    saveData();
    return { ...item };
  }

  static async update(id, values) {
    const index = this.rows.findIndex((row) => row.id === Number(id));
    if (index === -1) return null;
    this.rows[index] = { ...this.rows[index], ...values, id: Number(id) };
    saveData();
    return { ...this.rows[index] };
  }

  static async destroy(id) {
    const index = this.rows.findIndex((row) => row.id === Number(id));
    if (index === -1) return false;
    this.rows.splice(index, 1);
    saveData();
    return true;
  }
}

export class Diretor extends LocalModel {
  static collection = "diretores";
  static modelName = "Diretor";
}

export class Artista extends LocalModel {
  static collection = "artistas";
  static modelName = "Artista";
}

export class Filme extends LocalModel {
  static collection = "filmes";
  static modelName = "Filme";
}

export class FichaTecnica extends LocalModel {
  static collection = "fichasTecnicas";
  static modelName = "FichaTecnica";
}

export function resetData() {
  data = seedData();
  saveData();
}
