# Filmes Bootstrap

Sistema de cadastro de **Filmes**, **Diretores**, **Artistas** e **Fichas Técnicas** usando **Express**, **Handlebars** e **Bootstrap 5**.

## Entidades

| Entidade       | Telas                  |
|----------------|------------------------|
| Filme          | Listar · Cadastrar · Detalhar |
| Diretor        | Listar · Cadastrar · Detalhar |
| Artista        | Listar · Cadastrar · Detalhar |
| Ficha Técnica  | Listar · Cadastrar · Detalhar |

Também há edição e exclusão em todas as entidades.

## Relacionamentos

- Um **Diretor** dirige vários **Filmes** (1:N)
- Um **Filme** possui várias entradas de **Ficha Técnica** (1:N)
- Um **Artista** participa de várias **Fichas Técnicas** (1:N)

## Armazenamento

Dados salvos em `server/data.json` (criado automaticamente na primeira execução com dados de exemplo).  
Não usa banco de dados externo.

## Instalação e execução

```bash
npm install
npm start
```

Acesse: http://localhost:3000

Modo desenvolvimento (reinício automático):

```bash
npm run dev
```

Para limpar os dados: pare o servidor e apague `server/data.json`.

## Framework CSS

**Bootstrap 5** (via CDN) + Bootstrap Icons.

Código simples, sem uso da tag HTML `<button>` (usa `input type="submit"` e links com classes Bootstrap).
